/* FRIDAY is a simple and fun chatty bot for greeting the user and guessing their age.
* The bot will also test your knowledge with one simple question.                   */

import java.util.Scanner;

public class Main {

    final static Scanner scanner = new Scanner(System.in); // Do not change this line

    public static void main(String[] args) {
        // invoking the methods
        greet("FRIDAY", "2021");
        remindName();
        guessAge();
        count();
        test();
        end();
    }

    // greet the user and ask for this name
    static void greet(String assistantName, String birthYear) {
        System.out.println("Hello! My name is " + "FRIDAY" + ".");
        System.out.println("I was created in " + "2018" + ".");
        System.out.print("Please, remind me your name.\n> ");
    }

    // print the name of the user
    static void remindName() {
        String name = scanner.nextLine();
        System.out.println("What a great name you have, " + name + "!");
    }

    // guess the age of the user from the remainders
    static void guessAge() {
        System.out.println("Let me guess your age.");
        System.out.print("Enter remainders of dividing your age by 3, 5 and 7.\n> ");
        int rem3 = scanner.nextInt();
        int rem5 = scanner.nextInt();
        int rem7 = scanner.nextInt();
        int age = (rem3 * 70 + rem5 * 21 + rem7 * 15) % 105;
        System.out.println("Your age is " + age + "; that's a good time to start programming!");
    }

    // counts till the number entered by the user
    static void count() {
        System.out.print("Now I will prove to you that I can count to any number you want. \n> ");
        int num = scanner.nextInt();
        for (int i = 0; i <= num; i++) {
            System.out.printf("%d!\n", i);
        }
    }

    // test the user with one question
    static void test() {
        System.out.println("Let's test your programming knowledge.");
        System.out.print("Why do we use methods?\n" +
                "1. To repeat a statement multiple times.\n" +
                "2. To decompose a program into several small subroutines.\n" +
                "3. To determine the execution time of a program.\n" +
                "4. To interrupt the execution of a program. \n> ");
        int answer = scanner.nextInt();
        while (answer != 2) {
            System.out.print("Please, try again. \n> ");
            answer = scanner.nextInt();
        }
    }

    // end the program with a message
    static void end() {
        System.out.println("Congratulations, have a nice day!"); // Do not change this text
    }
}
